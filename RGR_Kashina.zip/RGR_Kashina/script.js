let products = [
    {image: 'ua.png', name: 'Ужас Аркхэма. Карточная игра', price: 3490},
    {image: 'upr.png', name: 'Игра Престолов. Второе издание', price: 5490 },
    {image: 'bm.png', name: 'Эпичные схватки боевых магов', price: 1490},
    {image: 'mp.png', name: 'Место преступления', price: 2990 },
    {image: 'sn.png', name: 'Dungeons & Dragons', price: 2490},
    {image: 'col.png', name: 'Catan: Колонизаторы', price: 3990 },
    {image: 'ev.png', name: 'Ticket to Ride: Европа', price: 4990},
    {image: 'zd.png', name: 'Зомби в доме: Заражение', price: 2990 },
    {image: 'mm.png', name: 'Small World: Маленький мир', price: 4990},
    {image: 'kt.png', name: 'Картографы', price: 990 },
    {image: 'ta.png', name: 'Таверна "Красный Дракон', price: 1790},
    {image: 'gf.png', name: 'Гравити Фолз', price: 2990 },
    {image: 'ss.png', name: 'Страшные сказки', price: 790},
    {image: 'sh.png', name: 'Spyfall: Находка для шпиона', price: 1290 },
    {image: 'b.png', name: 'Бэнг!', price: 990},
    {image: 'ne.png', name: 'Неудержимые единорожки', price: 990 },
    {image: 'pal.png', name: 'Палео', price: 4990 },
    {image: 'tr.png', name: 'Трамвай смерти', price: 2490},
    {image: 'kar.png', name: 'Каркассон', price: 1990 },
    {image: 'rm.png', name: 'Рик и Морти: Всмортить всё', price: 990},
];

function showModal(messageText, buttonText) {

    let modal = document.getElementsByClassName('modal')[0];
    modal.style.visibility = 'visible';
    modal.style.opacity ='1';
    modal.style.top ='200px';
    modal.style.transform = 'scale(1.5)';

    let message = modal.getElementsByClassName('message')[0];
    message.innerHTML = messageText;
    let button = modal.getElementsByTagName('button')[0];
    button.innerHTML = buttonText;

    document.body.style.overflow = 'hidden';
    let overlay = document.getElementsByClassName('overlay')[0];
    overlay.style.visibility = 'visible';
    overlay.style.opacity ='1';
    overlay.style.backgroundColor ='rgba(0, 0, 0, 0.3)';
}
function hideModal() {
    let modal = document.getElementsByClassName('modal')[0];
    setTimeout(function() {
        modal.style.visibility = 'hidden';
        modal.style.transform = 'scale(0)';
    }, 700)
    modal.style.opacity ='0';
    modal.style.top ='100%';
    modal.style.transform = 'scale(5)';

    document.body.style.overflow = 'auto';
    let overlay = document.getElementsByClassName('overlay')[0];
    setTimeout(function() {
        overlay.style.visibility = 'hidden';
    }, 400)
    overlay.style.opacity ='0';
    overlay.style.backgroundColor ='rgba(235, 140, 195, 0.548)';
}
function notReadyAlert(event) {
    showModal('Sorry, not ready yet!<br>Извините, еще не готово!', 'Эх, жаль');
    event.preventDefault();
    return false;
}
function F1() {
    showModal('Entrance from the courtyard, first floor.\nВход со внутреннего двора, первый этаж.', 'Окей!');
    return false;
}

function F2() {
    showModal('The best board games in town!\nЛучшие настольные игры в городе!', 'Верю!');
    return false;
}


function search() {
    let cards = document.getElementsByClassName('card');
    let name = document.getElementById('search').value;
    let nameRegExp = new RegExp(name, 'i');
    for(let i = 0; i<products.length; i++) {
        let product = products[i];
        if(nameRegExp.test(product.name)) {
            let card = cards[i];
              card.style.backgroundColor = 'LightSalmon';

    setTimeout (function () {
        card.style.border = 'none';
        card.style.backgroundColor = '';
    }, 2000);
}
    }
}

function generateMenu() {
    let menu = document.querySelector('nav.main-menu ul');
    menu.innerHTML = '';

    let items = [
        {href: 'index.html', text: 'Товары'},
        {href: 'contact.html', text: 'Контакты'},
        {href: '', text: 'Доставка'},
        {href: 'bonus.html', text: 'Акции'},
        {href: '', text: 'О нас'},
    ];

    for(let i = 0; i<items.length; i++) {
        let link = document.createElement('a');
        link.innerText = items[i].text;
        link.href = items[i].href;
        if(items[i].href == '') {
           link.addEventListener('click', notReadyAlert);
    }

        let menuItem = document.createElement('li');
        menuItem.appendChild(link);

        menu.appendChild(menuItem);
    }
}

function loaded() {
    let searchbox = document.getElementById('search');
    searchbox.addEventListener('keydown', function (key) {
        if (key.key == 'Enter'     )
             search();
    });

    generateMenu();
}